let dashboardButtons = document.querySelectorAll('[data-dropdown]')

dashboardButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        e.preventDefault()

        let icon = button.querySelector('i')

        if(!button.classList.contains('has-submenu')) {
            button.classList.add('has-submenu')
            icon.classList.add('active')
        } else {
            button.classList.remove('has-submenu')
            icon.classList.remove('active')
        }
    })
})
