<?php

class Request 
{

    public $url;
    public $controller = "ArticleController";
    public $task = "index";
    public $params = [];

    public function __construct($url)
    {
        $this->url = $url;

    }
}