const editor = document.getElementsByClassName('editor')[0];
const toolbar = editor.getElementsByClassName('toolbar')[0];
const buttons = toolbar.querySelectorAll('a');
const titles = [
  "h1", "h2", "h3", "h4", "h5", "h6",
]

const getContent = () => {
    document.getElementById("content").value = document.getElementById("textbox").innerHTML.trim();
}

buttons.forEach(button => {

  button.addEventListener('click', function(e) {
    e.preventDefault()
    let command = this.dataset.command;

    // custom action

    if(command === 'code') {
        const contentArea = editor.getElementsByClassName('content-area')[0];
        
        if(this.classList.contains('active')) { // show visuell view
            contentArea.innerHTML = contentArea.textContent;
            this.classList.remove('active');     
        } else {  // show html view
            contentArea.innerText = contentArea.innerHTML.trim();
            this.classList.add('active'); 
        }
      

    }
    
    if (command == 'createlink' || command == 'insertimage') {
      url = prompt('Enter the link here: ', 'http:\/\/');
      document.execCommand(command, false, url)
    } else if(titles.includes(command)) {
      document.execCommand('formatblock', false, command)
    } else if(command == 'fontname') {
      document.execCommand('fontname', false, button.innerText)
    } else if(command == 'fontsize') {
      document.execCommand('fontsize', false, this.dataset.value)
    } else {
      document.execCommand(command, false)
    }
  });

})